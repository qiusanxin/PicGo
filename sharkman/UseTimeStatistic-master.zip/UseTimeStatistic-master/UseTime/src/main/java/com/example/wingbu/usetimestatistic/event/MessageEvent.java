package com.example.wingbu.usetimestatistic.event;

/**
 * Created by Wingbu on 2017/7/18.
 */

public class MessageEvent {

    private String mMessage;

    public MessageEvent(String mMessage) {
        this.mMessage = mMessage;
    }

    public String getmMessage() {
        return mMessage;
    }

    public void setmMessage(String mMessage) {
        this.mMessage = mMessage;
    }
}
